﻿using Obligatorio1.Clases;

namespace Obligatorio1.Clases
{
    public class Socio
    {
        private int _idSocio;
        private string _tipoSocio;
        private string _nomSocio;
        private string _telefSocio;
        private string _mailSocio;
        private Local _local;

        public int IdSocio { get { return _idSocio; } set {  _idSocio = value; } }  
        public string TipoSocio { get { return _tipoSocio; } set { _tipoSocio = value; } }  
        public string NomSocio { get { return _nomSocio; } set { _nomSocio = value; } }
        public string TelefSocio { get { return _telefSocio; } set { _telefSocio = value; } }
        public string MailSocio { get { return _mailSocio; } set { _mailSocio = value; } }
        public Local Local { get { return _local;  } set { _local = value; } }  

        public Socio(int pIdSocio, string pTipoSocio, string pNomSocio, string pTelefSocio, string pMailSocio, Local pLocal)
        {
            this.IdSocio = pIdSocio;
            this.TipoSocio= pTipoSocio;
            this.NomSocio = pNomSocio;
            this.TelefSocio = pTelefSocio;
            this.MailSocio = pMailSocio;
            this.Local = pLocal;
        }
    }
}

