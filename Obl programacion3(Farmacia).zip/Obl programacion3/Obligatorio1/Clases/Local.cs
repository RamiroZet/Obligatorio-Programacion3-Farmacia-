﻿using Obligatorio1.Clases;

namespace Obligatorio1.Clases
{
    public class Local
    {
        private int _idLocal;
        private string _nomLocal;
        private string _ciudadLocal;
        private string _dirLocal;
        private string _teleLocal;
        private string _nomRespon;
        private string _teleRespon;

        public int IdLocal { get { return _idLocal; } set { _idLocal = value; } }
        public string NomLocal { get { return _nomLocal; } set { _nomLocal = value; } }
        public string CiudadLocal { get { return _ciudadLocal; } set { _ciudadLocal = value; } }
        public string DirLocal { get { return _dirLocal; } set { _dirLocal = value; } }
        public string TeleLocal { get { return _teleLocal; } set { _teleLocal = value; } }
        public string NomRespon { get { return _nomRespon; } set { _nomRespon = value; } }
        public string TeleRespon { get { return _teleRespon; } set { _teleRespon = value; } }

        public Local(int pIdLocal, string pNomLocal, string pCiudadLocal, string pDirLocal, string pTeleLocal, string pNomRespon, string pTeleRespon)
        {
            this.IdLocal = pIdLocal;
            this.NomLocal = pNomLocal;
            this.CiudadLocal = pCiudadLocal;
            this.DirLocal = pDirLocal;
            this.TeleLocal = pTeleLocal;
            this.NomRespon = pNomRespon;
            this.TeleRespon = pTeleRespon;
        }
    }
}
