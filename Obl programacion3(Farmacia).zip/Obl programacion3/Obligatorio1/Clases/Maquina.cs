﻿using Obligatorio1.Clases;

namespace Obligatorio1.Clases
{
    public class Maquina
    {
        private int _idMaq;
        private TipoMaquinas _tipoMaq;
        private Local _local;
        private DateTime _fechaCompra;
        private int _precioCompra;
        private int _vidautil;
        private string _disponible;

        public int IdMaq { get { return _idMaq; } set { _idMaq = value; } }
        public TipoMaquinas TipoMaq { get { return _tipoMaq; } set { _tipoMaq = value; } }
        public Local Local { get { return _local; } set { _local = value; } }
        public DateTime FechaCompra { get { return _fechaCompra; } set { _fechaCompra = value; } }
        public int PrecioCompra { get { return _precioCompra; } set { _precioCompra = value; } }
        public int VidaUtil { get { return _vidautil; } set { _vidautil = value; } }
        public string Disponible { get { return _disponible; } set { _disponible = value; } }



        public Maquina(int pIdMaq, TipoMaquinas pTipoMaq, Local pLocal, DateTime pFechaCompra, int pPrecioCompra, int pVidaUtil, string pDisponible)
        {
            this.IdMaq = pIdMaq;
            this.TipoMaq = pTipoMaq;
            this.Local = pLocal;
            this.FechaCompra = pFechaCompra;
            this.PrecioCompra = pPrecioCompra;
            this.VidaUtil = pVidaUtil;
            this.Disponible = pDisponible;
        }
    }
}
