﻿namespace Obligatorio1.Clases
{
    public class TipoMaquinas
    {
        private int _idTipoMaq;
        private string _nomTipoMaq;

        public int IdTipoMaq { get { return _idTipoMaq; } set { _idTipoMaq = value; } }
        public string NomTipoMaq { get { return _nomTipoMaq; } set { _nomTipoMaq = value; } }

        public TipoMaquinas(int pIdTipoMaq, string pNomTipoMaq)
        {
            this.IdTipoMaq = pIdTipoMaq;
            this.NomTipoMaq = pNomTipoMaq;
        }
    }
}
