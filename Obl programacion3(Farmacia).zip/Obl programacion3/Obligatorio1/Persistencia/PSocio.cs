﻿using Obligatorio1.Clases;
using System.Collections.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

namespace Obligatorio1.Persistencia
{
    public class PSocio
    {
        private static Conexion conexxion = new Conexion();

        public static bool AddSocio(Socio s)
        {
            string sql = "INSERT INTO Socio(IdSocio,TipoSocio,NomSocio,TelefSocio,MailSocio,IdLocal) VALUES (@idSocio,@tipoSocio,@nomSocio,@telefSocio,@mailSocio,@idLocal)";

            SqlParameter[] parametros =
            {
                new SqlParameter("@idSocio", SqlDbType.Int) {Value = s.IdSocio },
                new SqlParameter("@tipoSocio", SqlDbType.VarChar) {Value = s.TipoSocio  },
                new SqlParameter("@nomSocio", SqlDbType.VarChar) {Value = s.NomSocio },
                new SqlParameter("@telefSocio", SqlDbType.VarChar) {Value = s.TelefSocio },
                new SqlParameter("@mailSocio", SqlDbType.VarChar) {Value = s.MailSocio },
                new SqlParameter("@idLocal", SqlDbType.VarChar) {Value = s.Local.IdLocal },
            };

            conexxion.Consulta(sql, parametros);
            return true;
        }

        public static List<Socio> ListSocios()
        {
            string sql = "SELECT * FROM Socio";
            DataSet locales = conexxion.Seleccion(sql);

            List<Socio> listSocios = new List<Socio>();

            foreach (DataRow row in locales.Tables[0].Rows)
            {
                listSocios.Add(new Socio(Convert.ToInt32(row["idSocio"]), row["tipoSocio"].ToString(), row["nomSocio"].ToString(), row["telefSocio"].ToString(), row["mailSocio"].ToString(), PLocal.conseguirLocal(Convert.ToInt32(row["idLocal"].ToString()))));
            }
            return listSocios;
        }

        public static Boolean UpdateSocio(Socio s)
        {
            string sql = "UPDATE socio SET tipoSocio=@tipoSocio, nomSocio=@nomSocio, telefSocio=@telefSocio, mailSocio=@mailSocio, idLocal=@idLocal WHERE idSocio=@idSocio";

            SqlParameter[] parametros = {
                new SqlParameter("@idSocio", SqlDbType.Int) {Value = s.IdSocio },
                new SqlParameter("@tipoSocio", SqlDbType.VarChar) {Value = s.TipoSocio  },
                new SqlParameter("@nomSocio", SqlDbType.VarChar) {Value = s.NomSocio },
                new SqlParameter("@telefSocio", SqlDbType.VarChar) {Value = s.TelefSocio },
                new SqlParameter("@mailSocio", SqlDbType.VarChar) {Value = s.MailSocio },
                new SqlParameter("@idLocal", SqlDbType.VarChar) {Value = s.Local.IdLocal },
            };


            Console.WriteLine("Modificado con éxito");
            bool encontrado = conexxion.Consulta(sql, parametros);
            return encontrado;
        }

        public static Boolean DeleteSocio(int idSocio)
        {
            string sql = "DELETE Socio WHERE idSocio=@idSocio";

            SqlParameter[] parametros = {
                new SqlParameter("@idSocio", SqlDbType.Int) { Value = idSocio }
            };

            Console.WriteLine("Eliminado con éxito");
            bool encontrado = conexxion.Consulta(sql, parametros);
            return encontrado;
        }

        public static Socio GetSocio(int idSocio)
        {
            string sql = "SELECT * FROM Socio WHERE idSocio=@idSocio";

            SqlParameter[] parametros = {
                new SqlParameter("@idSocio", SqlDbType.Int) { Value = idSocio }
            };

            Console.WriteLine("Conseguido con éxito");
            DataSet data = conexxion.Seleccion(sql, parametros);
            DataRow row = data.Tables[0].Rows[0];
            return new Socio(Convert.ToInt32(row["idSocio"]), row["tipoSocio"].ToString(), row["nomSocio"].ToString(), row["telefSocio"].ToString(), row["mailSocio"].ToString(), PLocal.conseguirLocal(Convert.ToInt32(row["idLocal"].ToString())));
        }
        public static List<Socio> GetSocios()
        {
            string sql = "SELECT * FROM socio";

            Console.WriteLine("Conseguido con éxito");
            DataSet data = conexxion.Seleccion(sql);
            List<Socio> socios = new List<Socio>();
            foreach (DataRow row in data.Tables[0].Rows)
            {
                socios.Add(new Socio(Convert.ToInt32(row["idSocio"]), row["tipoSocio"].ToString(), row["nomSocio"].ToString(), row["telefSocio"].ToString(), row["mailSocio"].ToString(), PLocal.conseguirLocal(Convert.ToInt32(row["idLocal"].ToString()))));
            }
            return socios;
        }

        public static Socio conseguirSocio(int idSocio)
        {
            string sql = "SELECT * FROM Socio WHERE idSocio=@idSocio";

            SqlParameter[] parametros =
            {
                new SqlParameter("@idSocio", SqlDbType.Int) {Value = idSocio },
            };
            DataSet registros = conexxion.Seleccion(sql, parametros);

            DataRow registro = registros.Tables[0].Rows[0];

            Socio s = new Socio(Convert.ToInt32(registro["idSocio"]), registro["tipoSocio"].ToString(), registro["nomSocio"].ToString(), registro["telefSocio"].ToString(), registro["mailSocio"].ToString(), PLocal.conseguirLocal(Convert.ToInt32(registro["idLocal"].ToString())));
            return s;
        }

    }
}
