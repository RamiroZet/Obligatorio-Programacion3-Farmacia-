﻿using Obligatorio1.Clases;
using System.Collections.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

namespace Obligatorio1.Persistencia
{
    public class PLocal
    {
        private static Conexion conexxion = new Conexion();

        public static bool AddLocal(Local l)
        {
            string sql = "INSERT INTO Locales(IdLocal,NomLocal,CiudadLocal,DirLocal,TeleLocal,NomRespon,TeleRespon) VALUES (@idLocal,@nomLocal,@ciudadLocal,@dirLocal,@teleLocal,@nomRespon,@teleRespon)";

            SqlParameter[] parametros =
            {
                new SqlParameter("@idLocal", SqlDbType.Int) {Value = l.IdLocal },
                new SqlParameter("@nomLocal", SqlDbType.VarChar) {Value = l.NomLocal  },
                new SqlParameter("@ciudadLocal", SqlDbType.VarChar) {Value = l.CiudadLocal },
                new SqlParameter("@dirLocal", SqlDbType.VarChar) {Value = l.DirLocal },
                new SqlParameter("@teleLocal", SqlDbType.VarChar) {Value = l.TeleLocal },
                new SqlParameter("@nomRespon", SqlDbType.VarChar) {Value = l.NomRespon },
                new SqlParameter("@teleRespon", SqlDbType.VarChar) {Value = l.TeleRespon },
            };

            conexxion.Consulta(sql, parametros);
            return true;
        }

        public static List<Local> ListLocales()
        {
            string sql = "SELECT * FROM Locales";
            DataSet locales = conexxion.Seleccion(sql);

            List<Local> listLocales = new List<Local>();

            foreach (DataRow row in locales.Tables[0].Rows)
            {
                listLocales.Add(new Local(Convert.ToInt32(row["idLocal"]), row["nomLocal"].ToString(), row["ciudadLocal"].ToString(), row["dirLocal"].ToString(), row["teleLocal"].ToString(), row["nomRespon"].ToString(), row["teleRespon"].ToString()));
            }
            return listLocales;
        }

        public static Boolean UpdateLocal(Local l)
        {
            string sql = "UPDATE locales SET nomLocal=@nomLocal, ciudadLocal=@ciudadLocal, dirLocal=@dirLocal, teleLocal=@teleLocal, nomRespon=@nomRespon, teleRespon=@teleRespon WHERE idLocal=@idLocal";

            SqlParameter[] parametros = {
                new SqlParameter("@idLocal", SqlDbType.Int) {Value = l.IdLocal },
                new SqlParameter("@nomLocal", SqlDbType.VarChar) {Value = l.NomLocal  },
                new SqlParameter("@ciudadLocal", SqlDbType.VarChar) {Value = l.CiudadLocal },
                new SqlParameter("@dirLocal", SqlDbType.VarChar) {Value = l.DirLocal },
                new SqlParameter("@teleLocal", SqlDbType.VarChar) {Value = l.TeleLocal },
                new SqlParameter("@nomRespon", SqlDbType.VarChar) {Value = l.NomRespon },
                new SqlParameter("@teleRespon", SqlDbType.VarChar) {Value = l.TeleRespon },
            };


            Console.WriteLine("Modificado con éxito");
            bool encontrado = conexxion.Consulta(sql, parametros);
            return encontrado;
        }

        public static Boolean DeleteLocal(int idLocal)
        {
            string sql = "DELETE Locales WHERE idLocal=@idLocal";

            SqlParameter[] parametros = {
                new SqlParameter("@idLocal", SqlDbType.Int) { Value = idLocal }
            };

            Console.WriteLine("Eliminado con éxito");
            bool encontrado = conexxion.Consulta(sql, parametros);
            return encontrado;
        }

        public static Local GetLocal(int idLocal)
        {
            string sql = "SELECT * FROM Locales WHERE idLocal=@idLocal";

            SqlParameter[] parametros = {
                new SqlParameter("@idLocal", SqlDbType.Int) { Value = idLocal }
            };

            Console.WriteLine("Conseguido con éxito");
            DataSet data = conexxion.Seleccion(sql, parametros);
            DataRow row = data.Tables[0].Rows[0];
            return new Local(Convert.ToInt32(row["idLocal"]), row["nomLocal"].ToString(), row["ciudadLocal"].ToString(), row["dirLocal"].ToString(), row["teleLocal"].ToString(), row["nomRespon"].ToString(), row["teleRespon"].ToString());
        }
        public static List<Local> GetLocales()
        {
            string sql = "SELECT * FROM locales";

            Console.WriteLine("Conseguido con éxito");
            DataSet data = conexxion.Seleccion(sql);
            List<Local> locales = new List<Local>();
            foreach (DataRow row in data.Tables[0].Rows)
            {
                locales.Add(new Local(Convert.ToInt32(row["idLocal"]), row["nomLocal"].ToString(), row["ciudadLocal"].ToString(), row["dirLocal"].ToString(), row["teleLocal"].ToString(), row["nomRespon"].ToString(), row["teleRespon"].ToString()));
            }
            return locales;
        }

         public static Local conseguirLocal(int idLocal)
         {
             string sql = "SELECT * FROM Locales WHERE idLocal=@idLocal";

             SqlParameter[] parametros =
             {
                 new SqlParameter("@idLocal", SqlDbType.Int) {Value = idLocal },
             };
             DataSet registros = conexxion.Seleccion(sql, parametros);

             DataRow registro = registros.Tables[0].Rows[0];

             Local l = new Local(Convert.ToInt32(registro["idLocal"]), registro["nomLocal"].ToString(), registro["ciudadLocal"].ToString(), registro["dirLocal"].ToString(), registro["teleLocal"].ToString(), registro["nomRespon"].ToString(), registro["teleRespon"].ToString());
             return l;
         }
    }
}
