﻿using Obligatorio1.Clases;
using System.Collections.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

namespace Obligatorio1.Persistencia
{
    public class PMaquina
    {
        private static Conexion conexxion = new Conexion();

        public static bool AddMaquina(Maquina m)
        {
            string sql = "INSERT INTO Maquinas(IdMaq,IdTipoMaq,IdLocal,FechaCompra,PrecioCompra,VidaUtil,Disponible) VALUES (@idMaq,@idTipoMaq,@idLocal,@fechaCompra,@precioCompra,@vidaUtil,@disponible)";

            SqlParameter[] parametros =
            {
                new SqlParameter("@idMaq", SqlDbType.Int) {Value = m.IdMaq },
                new SqlParameter("@idTipoMaq", SqlDbType.VarChar) {Value = m.TipoMaq.IdTipoMaq  },
                new SqlParameter("@idLocal", SqlDbType.VarChar) {Value = m.Local.IdLocal },
                new SqlParameter("@fechaCompra", SqlDbType.Date) {Value = m.FechaCompra },
                new SqlParameter("@precioCompra", SqlDbType.VarChar) {Value = m.PrecioCompra },
                new SqlParameter("@vidaUtil", SqlDbType.Int) {Value = m.VidaUtil },
                new SqlParameter("@disponible", SqlDbType.VarChar) {Value = m.Disponible },
            };

            conexxion.Consulta(sql, parametros);
            return true;
        }

        public static List<Maquina> ListMaquinas()
        {
            string sql = "SELECT * FROM Maquinas";
            DataSet maquinas = conexxion.Seleccion(sql);

            List<Maquina> listMaquinas = new List<Maquina>();

            foreach (DataRow row in maquinas.Tables[0].Rows)
            {
                listMaquinas.Add(new Maquina(Convert.ToInt32(row["idMaq"]), PTipoMaq.conseguirTipoMaquina(Convert.ToInt32(row["idTipoMaq"].ToString())), PLocal.conseguirLocal(Convert.ToInt32(row["idLocal"].ToString())), Convert.ToDateTime(row["fechaCompra"].ToString()), Convert.ToInt32(row["precioCompra"].ToString()), Convert.ToInt32(row["vidaUtil"].ToString()), row["disponible"].ToString()));
            }
            return listMaquinas;
        }

        public static Boolean UpdateMaquina(Maquina m)
        {
            string sql = "UPDATE Maquinas SET idTipoMaq=@idTipoMaq, idLocal=@idLocal, fechaCompra=@fechaCompra, precioCompra=@precioCompra, vidaUtil=@vidaUtil, disponible=@disponible WHERE idMaq=@idMaq";

            SqlParameter[] parametros = {
                new SqlParameter("@idMaq", SqlDbType.Int) {Value = m.IdMaq },
                new SqlParameter("@idTipoMaq", SqlDbType.VarChar) {Value = m.TipoMaq.IdTipoMaq  },
                new SqlParameter("@idLocal", SqlDbType.VarChar) {Value = m.Local.IdLocal },
                new SqlParameter("@fechaCompra", SqlDbType.Date) {Value = m.FechaCompra },
                new SqlParameter("@precioCompra", SqlDbType.VarChar) {Value = m.PrecioCompra },
                new SqlParameter("@vidaUtil", SqlDbType.Int) {Value = m.VidaUtil },
                new SqlParameter("@disponible", SqlDbType.VarChar) {Value = m.Disponible },
            };


            Console.WriteLine("Modificado con éxito");
            bool encontrado = conexxion.Consulta(sql, parametros);
            return encontrado;
        }

        public static Boolean DeleteMaquina(int idMaq)
        {
            string sql = "DELETE Maquinas WHERE idMaq=@idMaq";

            SqlParameter[] parametros = {
                new SqlParameter("@idMaq", SqlDbType.Int) { Value = idMaq }
            };

            Console.WriteLine("Eliminado con éxito");
            bool encontrado = conexxion.Consulta(sql, parametros);
            return encontrado;
        }

        public static Maquina GetMaquina(int idMaq)
        {
            string sql = "SELECT * FROM Maquinas WHERE idMaq=@idMaq";

            SqlParameter[] parametros = {
                new SqlParameter("@idMaq", SqlDbType.Int) { Value = idMaq }
            };

            Console.WriteLine("Conseguido con éxito");
            DataSet data = conexxion.Seleccion(sql, parametros);
            DataRow row = data.Tables[0].Rows[0];
            return new Maquina(Convert.ToInt32(row["idMaq"]), PTipoMaq.conseguirTipoMaquina(Convert.ToInt32(row["idTipoMaq"].ToString())), PLocal.conseguirLocal(Convert.ToInt32(row["idLocal"].ToString())), Convert.ToDateTime(row["fechaCompra"].ToString()), Convert.ToInt32(row["precioCompra"].ToString()), Convert.ToInt32(row["vidaUtil"].ToString()), row["disponible"].ToString());
        }
        public static List<Maquina> GetMaquinas()
        {
            string sql = "SELECT * FROM Maquinas";

            Console.WriteLine("Conseguido con éxito");
            DataSet data = conexxion.Seleccion(sql);
            List<Maquina> maquinas = new List<Maquina>();
            foreach (DataRow row in data.Tables[0].Rows)
            {
                maquinas.Add(new Maquina(Convert.ToInt32(row["idMaq"]), PTipoMaq.conseguirTipoMaquina(Convert.ToInt32(row["idTipoMaq"].ToString())), PLocal.conseguirLocal(Convert.ToInt32(row["idLocal"].ToString())), Convert.ToDateTime(row["fechaCompra"].ToString()), Convert.ToInt32(row["precioCompra"].ToString()), Convert.ToInt32(row["vidaUtil"].ToString()), row["disponible"].ToString()));
            }
            return maquinas;
        }

        public static Maquina conseguirMaquina(int idMaq)
        {
            string sql = "SELECT * FROM Maquinas WHERE idMaq=@idMaq";

            SqlParameter[] parametros =
            {
                new SqlParameter("@idMaq", SqlDbType.Int) {Value = idMaq },
            };
            DataSet registros = conexxion.Seleccion(sql, parametros);

            DataRow registro = registros.Tables[0].Rows[0];

            Maquina m = new Maquina(Convert.ToInt32(registro["idMaq"]), PTipoMaq.conseguirTipoMaquina(Convert.ToInt32(registro["idTipoMaq"].ToString())), PLocal.conseguirLocal(Convert.ToInt32(registro["idLocal"].ToString())), Convert.ToDateTime(registro["fechaCompra"].ToString()), Convert.ToInt32(registro["precioCompra"].ToString()), Convert.ToInt32(registro["vidaUtil"].ToString()), registro["disponible"].ToString());
            return m;
        }
    }
}
