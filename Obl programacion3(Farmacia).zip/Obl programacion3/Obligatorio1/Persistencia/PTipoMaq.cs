﻿using Obligatorio1.Clases;
using System.Collections.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

namespace Obligatorio1.Persistencia
{
    public class PTipoMaq
    {
        private static Conexion conexxion = new Conexion();

        public static bool AddTipoMaquina(TipoMaquinas tm)
        {
            string sql = "INSERT INTO TipoMaquinas(IdTipoMaq,NomTipoMaq) VALUES (@idTipoMaq,@nomTipoMaq)";

            SqlParameter[] parametros =
            {
                new SqlParameter("@idTipoMaq", SqlDbType.Int) {Value = tm.IdTipoMaq },
                new SqlParameter("@nomTipoMaq", SqlDbType.VarChar) {Value = tm.NomTipoMaq  },
            };

            conexxion.Consulta(sql, parametros);
            return true;
        }

        public static List<TipoMaquinas> ListTipoMaquinas()
        {
            string sql = "SELECT * FROM TipoMaquinas";
            DataSet tipomaquinas = conexxion.Seleccion(sql);

            List<TipoMaquinas> listtipomaquinas = new List<TipoMaquinas>();

            foreach (DataRow row in tipomaquinas.Tables[0].Rows)
            {
                listtipomaquinas.Add(new TipoMaquinas(Convert.ToInt32(row["idTipoMaq"]), row["nomTipoMaq"].ToString()));
            }
            return listtipomaquinas;
        }

        public static Boolean UpdateTipoMaquina(TipoMaquinas tm)
        {
            string sql = "UPDATE TipoMaquinas SET nomTipoMaq=@nomTipoMaq WHERE idTipoMaq=@idTipoMaq";

            SqlParameter[] parametros = {
                new SqlParameter("@idTipoMaq", SqlDbType.Int) {Value = tm.IdTipoMaq },
                new SqlParameter("@nomTipoMaq", SqlDbType.VarChar) {Value = tm.NomTipoMaq  },
            };

            Console.WriteLine("Modificado con éxito");
            bool encontrado = conexxion.Consulta(sql, parametros);
            return encontrado;
        }

        public static Boolean DeleteTipoMaquina(int idTipoMaq)
        {
            string sql = "DELETE TipoMaquinas WHERE idTipoMaq=@idTipoMaq";

            SqlParameter[] parametros = {
                new SqlParameter("@idTipoMaq", SqlDbType.Int) { Value = idTipoMaq }
            };

            Console.WriteLine("Eliminado con éxito");
            bool encontrado = conexxion.Consulta(sql, parametros);
            return encontrado;
        }

        public static TipoMaquinas GetTipoMaquina(int idTipoMaq)
        {
            string sql = "SELECT * FROM TipoMaquinas WHERE idTipoMaq=@idTipoMaq";

            SqlParameter[] parametros = {
                new SqlParameter("@idTipoMaq", SqlDbType.Int) { Value = idTipoMaq }
            };

            Console.WriteLine("Conseguido con éxito");
            DataSet data = conexxion.Seleccion(sql, parametros);
            DataRow row = data.Tables[0].Rows[0];
            return new TipoMaquinas(Convert.ToInt32(row["idTipoMaq"]), row["nomTipoMaq"].ToString());
        }
        public static List<TipoMaquinas> GetTipoMaquina()
        {
            string sql = "SELECT * FROM TipoMaquinas";

            Console.WriteLine("Conseguido con éxito");
            DataSet data = conexxion.Seleccion(sql);
            List<TipoMaquinas> tipomaquinas = new List<TipoMaquinas>();
            foreach (DataRow row in data.Tables[0].Rows)
            {
                tipomaquinas.Add(new TipoMaquinas(Convert.ToInt32(row["idTipoMaq"]), row["nomTipoMaq"].ToString()));
            }
            return tipomaquinas;
        }

        public static TipoMaquinas conseguirTipoMaquina(int idTipoMaq)
        {
            string sql = "SELECT * FROM TipoMaquinas WHERE idTipoMaq=@idTipoMaq";

            SqlParameter[] parametros =
            {
                 new SqlParameter("@idTipoMaq", SqlDbType.Int) {Value = idTipoMaq },
             };
            DataSet registros = conexxion.Seleccion(sql, parametros);

            DataRow registro = registros.Tables[0].Rows[0];

            TipoMaquinas tm = new TipoMaquinas(Convert.ToInt32(registro["idTipoMaq"]), registro["nomTipoMaq"].ToString());
            return tm;
        }
    }
}
