using Obligatorio1.Clases;
using Obligatorio1.Persistencia;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Obligatorio1.Pages.PaginaLocal
{
    public class AltaLocalModel : PageModel
    {
        public void OnGet()
        {
        }

        public IActionResult OnPostAgregarLocal()
        {
            Local l = new Local(Convert.ToInt32(Request.Form["idLocal"]), Request.Form["nomLocal"], Request.Form["ciudadLocal"], Request.Form["dirLocal"], Request.Form["teleLocal"], Request.Form["nomRespon"], Request.Form["teleRespon"]);
            PLocal.AddLocal(l);
            return Redirect("/Index");
        }
    }
}
