using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Obligatorio1.Clases;
using Obligatorio1.Persistencia;

namespace Obligatorio1.Pages.PaginaLocal
{
    public class UpdateMaquinaModel : PageModel
    {
        public Maquina m { get; set; }
        public void OnGet(int id)
        {
            m = PMaquina.conseguirMaquina(id);
        }
        public IActionResult OnPostModificarMaquina()
        {
            Console.WriteLine(Request.Form[""]);
            Maquina m = new Maquina(Convert.ToInt32(Request.Form["idMaq"]),PTipoMaq.conseguirTipoMaquina(Convert.ToInt32(Request.Form["idTipoMaq"])), PLocal.conseguirLocal(Convert.ToInt32(Request.Form["idLocal"])), Convert.ToDateTime(Request.Form["fechaCompra"]), Convert.ToInt32(Request.Form["precioCompra"]), Convert.ToInt32(Request.Form["vidaUtil"]), Request.Form["disponible"]);
            PMaquina.UpdateMaquina(m);
            return Redirect("./ListMaquina");
        }
    }
}
