using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Obligatorio1.Clases;
using Obligatorio1.Persistencia;

namespace Obligatorio1.Pages.PaginaLocal
{
    public class ListTipoMaqModel : PageModel
    {
        public List<TipoMaquinas> tipomaquinas { get; set; }
        public void OnGet()
        {
            tipomaquinas = PTipoMaq.GetTipoMaquina();
        }
        public IActionResult OnPostDeleteTipoMaq()
        {
            int idTipoMaq = Convert.ToInt32(Request.Form["idTipoMaq"]);
            Console.WriteLine(idTipoMaq);
            PTipoMaq.DeleteTipoMaquina(idTipoMaq);
            return RedirectToPage("./ListTipoMaq");
        }
    }
}
