using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Obligatorio1.Clases;
using Obligatorio1.Persistencia;

namespace Obligatorio1.Pages.PaginaLocal
{
    public class ListSocioModel : PageModel
    {
        public List<Socio> socios { get; set; }
        public void OnGet()
        {
            socios = PSocio.GetSocios();
        }
        public IActionResult OnPostDeleteSocio()
        {
            int idSocio = Convert.ToInt32(Request.Form["idSocio"]);
            Console.WriteLine(idSocio);
            PSocio.DeleteSocio(idSocio);
            return RedirectToPage("./ListSocio");
        }
    }
}
