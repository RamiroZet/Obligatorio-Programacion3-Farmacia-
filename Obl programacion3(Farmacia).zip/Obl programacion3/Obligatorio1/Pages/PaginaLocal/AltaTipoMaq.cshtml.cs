using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Obligatorio1.Clases;
using Obligatorio1.Persistencia;

namespace Obligatorio1.Pages.PaginaLocal
{
    public class AltaTipoMaqModel : PageModel
    {
        public void OnGet()
        {
        }
        public IActionResult OnPostAgregarTipoMaq()
        {
            TipoMaquinas tm = new TipoMaquinas(Convert.ToInt32(Request.Form["idTipoMaq"]), Request.Form["nomTipoMaq"]);
            PTipoMaq.AddTipoMaquina(tm);
            return Redirect("/Index");
        }
    }
}
