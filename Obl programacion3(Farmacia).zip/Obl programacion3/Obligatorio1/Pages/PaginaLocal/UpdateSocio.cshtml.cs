using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Obligatorio1.Clases;
using Obligatorio1.Persistencia;

namespace Obligatorio1.Pages.PaginaLocal
{
    public class UpdateSocioModel : PageModel
    {
        public Socio s { get; set; }
        public void OnGet(int id)
        {
            s = PSocio.conseguirSocio(id);
        }
        public IActionResult OnPostModificarSocio()
        {
            Socio s = new Socio(Convert.ToInt32(Request.Form["idSocio"]), Request.Form["tipoSocio"], Request.Form["nomSocio"], Request.Form["telefSocio"], Request.Form["mailSocio"], PLocal.conseguirLocal(Convert.ToInt32(Request.Form["idLocal"])));
            PSocio.UpdateSocio(s);
            return Redirect("./ListSocio");
        }
    }
}
