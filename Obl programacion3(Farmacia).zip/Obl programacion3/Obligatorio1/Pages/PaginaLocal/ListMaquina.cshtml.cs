using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Obligatorio1.Clases;
using Obligatorio1.Persistencia;

namespace Obligatorio1.Pages.PaginaLocal
{
    public class ListMaquinaModel : PageModel
    {
        public List<Maquina> maquinas { get; set; }
        public void OnGet()
        {
            maquinas = PMaquina.GetMaquinas();
        }
        public IActionResult OnPostDeleteMaquina()
        {
            int idMaq = Convert.ToInt32(Request.Form["idMaq"]);
            Console.WriteLine(idMaq);
            PMaquina.DeleteMaquina(idMaq);
            return RedirectToPage("./ListMaquina");
        }
    }
}
