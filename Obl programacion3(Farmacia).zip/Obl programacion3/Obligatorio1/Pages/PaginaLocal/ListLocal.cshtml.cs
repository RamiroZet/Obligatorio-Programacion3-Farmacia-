using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Obligatorio1.Clases;
using Obligatorio1.Persistencia;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Obligatorio1.Pages.PaginaLocal
{
    public class ListLocalModel : PageModel
    {
        public List<Local> locales { get; set; }
        public void OnGet()
        {
            locales = PLocal.GetLocales();
        }

        public IActionResult OnPostDeleteLocal()
        {
            int idLocal = Convert.ToInt32(Request.Form["idLocal"]);
            Console.WriteLine(idLocal);
            PLocal.DeleteLocal(idLocal);
            return RedirectToPage("./ListLocal");
        }
    }
}
