using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Obligatorio1.Clases;
using Obligatorio1.Persistencia;

namespace Obligatorio1.Pages.PaginaLocal
{
    public class AltaMaquinaModel : PageModel
    {
        public List<TipoMaquinas> tipomaquinas { get; set; } 
        public List<Local> locales { get; set; }
        public void OnGet()
        {
            tipomaquinas = PTipoMaq.GetTipoMaquina(); 
            locales = PLocal.GetLocales();
        }
        public IActionResult OnPostAgregarMaquina()
        {
            Maquina m = new Maquina(Convert.ToInt32(Request.Form["idMaq"]), PTipoMaq.conseguirTipoMaquina(Convert.ToInt32(Request.Form["ListaTipoMaq"])), PLocal.conseguirLocal(Convert.ToInt32(Request.Form["ListaLocal"])), Convert.ToDateTime(Request.Form["fechaCompra"]), Convert.ToInt32(Request.Form["precioCompra"]), Convert.ToInt32(Request.Form["vidaUtil"]), Request.Form["disponible"]);
            PMaquina.AddMaquina(m);
            return Redirect("/Index");
        }
    }
}
