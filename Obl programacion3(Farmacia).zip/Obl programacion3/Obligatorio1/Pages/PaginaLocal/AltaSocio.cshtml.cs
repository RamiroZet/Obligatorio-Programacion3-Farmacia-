using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Obligatorio1.Clases;
using Obligatorio1.Persistencia;

namespace Obligatorio1.Pages.PaginaLocal
{
 
    public class AltaSocioModel : PageModel
    {
        public List<Local> locales { get; set; }
        public void OnGet()
        {
            locales = PLocal.GetLocales();
        }
        public IActionResult OnPostAgregarSocio()
        {
            Socio s = new Socio(Convert.ToInt32(Request.Form["idSocio"]), Request.Form["tipoSocio"], Request.Form["nomSocio"], Request.Form["telefSocio"], Request.Form["mailSocio"], PLocal.conseguirLocal(Convert.ToInt32(Request.Form["ListaLocal"])));
            PSocio.AddSocio(s);
            return Redirect("/Index");
        }
    }
}
