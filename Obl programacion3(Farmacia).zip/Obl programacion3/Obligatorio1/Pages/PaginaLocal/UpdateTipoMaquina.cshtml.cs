using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Obligatorio1.Clases;
using Obligatorio1.Persistencia;

namespace Obligatorio1.Pages.PaginaLocal
{
    public class UpdateTipoMaquinaModel : PageModel
    {
        public TipoMaquinas tm { get; set; }
        public void OnGet(int id)
        {
            tm = PTipoMaq.conseguirTipoMaquina(id);
        }

        public IActionResult OnPostModificarTipoMaq()
        {
            TipoMaquinas tm = new TipoMaquinas(Convert.ToInt32(Request.Form["idTipoMaq"]), Request.Form["nomTipoMaq"]);
            PTipoMaq.UpdateTipoMaquina(tm);
            return Redirect("./ListTipoMaq");
        }
    }
}
