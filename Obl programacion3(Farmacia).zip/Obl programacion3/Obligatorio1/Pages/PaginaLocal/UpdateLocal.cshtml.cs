﻿using Obligatorio1.Clases;
using Obligatorio1.Persistencia;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;


namespace Obligatorio1.Pages.PaginaLocal
{
    public class UpdateLocalModel : PageModel
    {
        public Local l { get; set; }
        public void OnGet(int id)
        {
            l = PLocal.conseguirLocal(id);

        }

        public IActionResult OnPostModificarLocal()
        {
            Local l = new Local(Convert.ToInt32(Request.Form["idLocal"]), Request.Form["nomLocal"], Request.Form["ciudadLocal"], Request.Form["dirLocal"], Request.Form["teleLocal"], Request.Form["nomRespon"], Request.Form["teleRespon"]);
            PLocal.UpdateLocal(l);
            return Redirect("./ListLocal");
        }
    }
}
