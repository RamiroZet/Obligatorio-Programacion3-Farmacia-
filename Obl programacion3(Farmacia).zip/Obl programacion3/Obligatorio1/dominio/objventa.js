﻿venta = {
	
	ventas:[],
	
	crear:function(id, fecha, objMedicamento, cantidad, monto){
		const venta = new Object();
		    venta.id = id;
			venta.fecha = fecha;
			venta.objMedicamento = objMedicamento;
			venta.cantidad = cantidad;
			venta.monto = monto;
		
	        return venta;
	},
	
alta: function (){
        let id = document.getElementById("id").value;	
        let fecha = document.getElementById("fecha").value;	
        let texto = document.getElementById("objMedicamento").value;	
        let arrayM = texto.split(" ");
		let idM = arrayM[0];
		let objMedicamento = this.devuelveObj(idM);
		let cantidad = parseInt(document.getElementById("cantidad").value);	
        let stock = parseInt(objMedicamento.stock);
        let precio = parseInt(objMedicamento.precio);
        if(cantidad > stock){
			alert("no hay stock para vender")
		    return 
		}
		let monto = cantidad*precio;
		document.getElementById("monto").value= monto;
		objMedicamento.stock =  objMedicamento.stock - cantidad;
		
        let objVenta = this.crear(id, fecha, objMedicamento, cantidad, monto);
		this.ventas.push(objVenta);
		medicamento.listar();
		
        this.listar();
        //this.limpiar();    	 
},
baja: function (){
	    let id = document.getElementById("id").value;
        let pos = this. buscarPos(id);        
        if (pos < 0) {
            alert("Error en baja: la venta con este ID no existe");
        }        
        else{
            this.ventas.splice(pos, 1);
            this.listar();
            alert("venta borrado con exito");
       }
        this.limpiar();
},
listar: function () {
 let lista = document.getElementById("listaVenta").options;
        lista.length = 0;
        
        for (let objVenta of this.ventas) {
            let texto = objVenta.id + " " + 						
                        objVenta.fecha+ " " + 
						objVenta.objMedicamento.nombre+" " + 
						objVenta.cantidad+" "+
						objVenta.monto;
            
            let elemento = new Option(texto);
            lista.add(elemento);
        }
},
seleccionar: function (){
	let lista = document.getElementById("listaVenta");
	let i = lista.selectedIndex;
	document.getElementById("id").value 	  = this.ventas[0].id;
	document.getElementById("fecha").value   = this.ventas[i].fecha;
	document.getElementById("objmedicamento").value   = this.ventas[i].objmedicamento;
	document.getElementById("cantidad").value 	  = this.ventas[i].cantidad;
	document.getElementById("monto").value 	  = this.ventas[i].monto;
},
buscarPos: function (id) {
        for (let pos = 0; pos < this.ventas.length; pos++) {
            let objVenta = this.ventas[pos];
            if (objVenta.id == id) {
                return pos;
            }
        }
return -1;
},
devuelveObj: function (id) {
        for (let objMedicamento of medicamento.medicamentos) {
            if (objMedicamento.id == id) {
                return objMedicamento;
            }
        }
return null;
},
limpiar: function(){
    document.getElementById("abmVenta").reset();    
    

},
//Estadistica
masVendido: function (){
	let mayor = 0;
	let elMasVendido = venta;
	
	for (let objVenta of this.ventas) {
		if (objVenta.cantidad > mayor) {
			mayor = objVenta.cantidad;
			elMasVendido = objVenta;
		}
	}			   
		alert("El medicamento mas vendido es:"+elMasVendido.objMedicamento.nombre);
},
sumarVentas: function (){
	let suma = 0;
	for(let objVenta of venta.ventas){
		suma += objVenta.monto;
	}
	alert(suma)
}
}