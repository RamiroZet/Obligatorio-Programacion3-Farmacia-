/***   Clase medicamento
    estudiante = {  
        medicamentos :[], 
        crear       :function(id, codigo, nombre, precio, stock){},  
        alta        :function(){},  
        baja        :function(){},
        modificar   :function(){}, 
        listar      :function(){}, 
        buscarPos   :function(id){}, 
        limpiar     :function(){} 
    };
*/
//un obj son propiedades y metodos
medicamento = {
    
medicamentos: [],
//***   Arrays de Objetos estudiante


//***   Método constructor el objeto estudiante
crear: function (id, nombre, precio, stock) {  

        const medicamento = new Object();
        medicamento.id      = id;
        medicamento.nombre  = nombre;
        medicamento.precio  = precio;
        medicamento.stock   = stock;
       return medicamento;
},

//***   Método alta: permite ingresar un objeto.value es valor actual, osea lo q el usuario ingresar
alta: function () {
        let id      = document.getElementById("id").value;
        let nombre  = document.getElementById("nombre").value;
        let precio  = document.getElementById("precio").value;
        let stock   = document.getElementById("stock").value;
            
        let objMedicamento = this.crear(id, nombre, precio, stock);//this hace referencia al obj 
		this.medicamentos.push(objMedicamento);
        this.listar();
        //this.limpiar();    
},

//***   Método baja: permite eliminar una objeto
baja: function () {
        let id = document.getElementById("id").value;
        let pos = this. buscarPos(id);        
        if (pos < 0) {
            alert("Error en baja: Medicamento con este ID no existe");
        }        
        else{
            this.medicamentos.splice(pos, 1);
            this.listar();
            alert("Medicamento borrado con exito");
       }
        this.limpiar();
},

//***   Método modificar: permite modificar el objeto, no modifica id.
modi: function () {
        let id  = document.getElementById("id").value;
        let pos = this.buscarPos(id);
        if (pos < 0) {
            alert("Error en modificar: no existe medicamento con este ID");
        } 
        else {
            let objMedicamento = this.medicamentos[pos];  
            let nombre        = document.getElementById("nombre").value;
            let precio      = document.getElementById("precio").value;
            let stock          = document.getElementById("stock").value;
           
 //*** asigna el valor, se accede a la "propiedad" dependiendo de como se llame la variable
            objMedicamento.nombre   = nombre;
            objMedicamento.precio   = precio;
            objMedicamento.stock    = stock;
            this.listar();
            alert("Modificado con éxito!!")
        }
        this.listar();
},

//***   Método listar: agrega a la lista del formulario un objeto
listar: function (medicamentos = this.medicamentos) {
 let lista = document.getElementById("listaMedicamento").options; //el options significa q se maneja con un Select
        lista.length = 0; // actualiza la lista en caso de duplicados y datos anteriores
        
        for (let objMedicamento of medicamentos) {
            let texto = objMedicamento.id + " " + 						
                        objMedicamento.nombre+ " " + 
						objMedicamento.precio+" " + 
						objMedicamento.stock;
            
            let elemento = new Option(texto);
            lista.add(elemento);
        }
},

seleccionar: function (){
	let lista = document.getElementById("listaMedicamento");
	let i = lista.selectedIndex;
	document.getElementById("id").value 	  = this.medicamentos[0].id;
	document.getElementById("nombre").value   = this.medicamentos[i].nombre;
	document.getElementById("precio").value   = this.medicamentos[i].precio;
	document.getElementById("stock").value 	  = this.medicamentos[i].stock;
},
cargarEnVenta: function (){
	let pos = document.getElementById("listaMedicamento").selectedIndex;
	if(pos<0){
		alert("Error en seleccionar");
	}
	else{
		let objMedicamento = this.medicamentos[pos];
        
		document.getElementById("objMedicamento").value  = objMedicamento.id+ " " + objMedicamento.nombre
		document.getElementById("stockM").value           = objMedicamento.stock;
        document.getElementById("precioM").value          = objMedicamento.precio;
	}
 /*   
    let lista = document.getElementById("listaMedicamento");
	let i = lista.selectedIndex; 
	document.getElementById("objmedicamento").value = this.medicamentos[i].id +" "+this.medicamentos[i].nombre;
	document.getElementById("stockM").value         = this.medicamentos[i].stock;
	document.getElementById("precioM").value        = this.medicamentos[i].precio;**/

},

//***   Método buscarPos: busca la posición de un objeto en el array de objetos.
buscarPos: function (id) {
        for (let pos = 0; pos < this.medicamentos.length; pos++) {
            let objMedicamento = this.medicamentos[pos];
            if (objMedicamento.id == id) {
                return pos;
            }
        }
return -1;
},

ordenar: function () {
	if (document.getElementById("alfa").checked) {
		const listaOrdenada = this.ordenoBurbuja();
		this.listar(listaOrdenada);
		
	}else {
		this.listar();
	}
},
ordenoBurbuja: function () {
	let listaOrdenada = [...this.medicamentos];
	for(let i = 0; i < listaOrdenada.length - 1; i++) {
		//los dos for tienen que tener variables !=, ejemplo i j
		for(let j = 0; j < listaOrdenada.length - 1; j++) {
			//listaOrdenada.length - 1, resta para que el ultimo se pueda comparar sino no compara al ultimo
			if(listaOrdenada[j].nombre > listaOrdenada[j + 1].nombre) {
				const temp = listaOrdenada[j];
				listaOrdenada[j] = listaOrdenada[j + 1]
				listaOrdenada[j + 1] = temp;
			}
		}
	}
	return listaOrdenada;
}
//***   Método limpiar: limpia la entrada de datos del formulario

}